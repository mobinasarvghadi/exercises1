﻿using System;

namespace perimeter
{
    class Program
    {
        static void Main(string[] args)
        {
            double a, perimeter, area;

            Console.Write("Enter the radius of the circle: ");
            a = Int32.Parse(Console.ReadLine());

            perimeter = 2 * a * Math.PI;
            area = Math.PI * a * a;

            Console.WriteLine("area is {0} and perimeter is {1}", area, perimeter);



            Console.ReadKey();
        }
    }
}
