﻿using System;

namespace TemperatureConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            double celsius, fahrenheit;

            Console.Write("Enter temperature in Celsius: ");
            celsius = Double.Parse(Console.ReadLine());

            fahrenheit = (celsius * 9 / 5) + 32;

            Console.WriteLine("Temperature in Fahrenheit: {0}", fahrenheit);

            Console.ReadKey();
        }
    }
}
