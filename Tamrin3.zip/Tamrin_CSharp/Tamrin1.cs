using System;

class Program {
    static void Main() {
        Console.Write("Adade ro vared kon (1 ta 7): ");
        int day = int.Parse(Console.ReadLine());

        switch (day) {
            case 1: Console.WriteLine("Shanbe"); break;
            case 2: Console.WriteLine("Yekshanbe"); break;
            case 3: Console.WriteLine("Doshanbe"); break;
            case 4: Console.WriteLine("Seshhanbe"); break;
            case 5: Console.WriteLine("Chaharshanbe"); break;
            case 6: Console.WriteLine("Panjshanbe"); break;
            case 7: Console.WriteLine("Jome"); break;
            default: Console.WriteLine("end"); break;
        }
    }
}