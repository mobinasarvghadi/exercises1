using System;

class Program
{
	static void Main()
	{
		int result = 1; 
		int number;
		Console.WriteLine("add ro vard kon:");

		while (true)
		{
			Console.Write("add ro vard kon:");
			number = int.Parse(Console.ReadLine());

			if (number == 0)
				break; 

			result *= number;  
			Console.WriteLine("nteji: " + result);  
		}
	}
}