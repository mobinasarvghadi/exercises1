using System;

class Program
{
	static void Main()
	{
		Console.WriteLine("I:");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if (j == 1(i == 0  i == 2))
					Console.Write("*");
				else
					Console.Write(" ");
			}
			Console.WriteLine();
		}

		Console.WriteLine();

		Console.WriteLine("H:");
		for (int i = 0; i < 3; i++)
		{
			for (int j = 0; j < 3; j++)
			{
				if (j == 0  j == 2(i == 1 && j == 1))
                    Console.Write("*");

				else
			Console.Write(" ");
	}
	Console.WriteLine();
        }

Console.WriteLine();

Console.WriteLine("E:");
for (int i = 0; i < 3; i++)
{
	for (int j = 0; j < 3; j++)
	{
		if (j == 0  i == 0  i == 1)
                    Console.Write("*");

				else
	Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}